# Avaliação de skills — MCP Market (Game Development)

**Data:** 2026-10-17 · **Fonte:** [mcpmarket.com/tools/skills/categories/game-development](https://mcpmarket.com/tools/skills/categories/game-development)

## O que é isso, afinal

"Agent Skills" são **manuais em arquivo `.md`** (com scripts às vezes) que uma IA carrega e segue — tipo um procedimento embutido. Não são mágica: são instruções de terceiro. Duas implicações:

1. **Para mim (chefe na sessão):** não existe "instalar skill" aqui; basta deixar a skill revisada em `skills/` no repo e citá-la no `AGENTS.md` — eu leio e sigo. Para IAs locais em clientes com suporte a skills/MCP (Claude Desktop, Cline, Continue etc.), a instalação é nativa.
2. **Risco:** skill de terceiro é **prompt executado pela IA**. Skill mal-intencionada ou desatualizada manda seu agent fazer bobagem. Revisão antes de uso é obrigatória.

## O catálogo (amostra da página 1 de 100 — 3.427 itens no total)

Categorias que aparecem: engines (Unreal/Unity/Godot/Bevy), web 3D (muitas Three.js), shaders, assets 3D, design de jogo, e automação de jogos alheios (evitar).

## Recomendação por utilidade

### ✅ Valem a revisão (para o nosso caso)

| Skill | Por quê | Quando usar |
|---|---|---|
| **Game Design Principles & GDD Architect** | Estrutura de GDD, core loop, psicologia do jogador | Agora — na montagem da documentação completa |
| **Unreal Engine C++ Pro** | Padrões de código UE 5.x, performance, memória | Se a Unreal ganhar o teste de engine |
| **Godot GDScript Patterns** | Arquitetura Godot 4, sinais, state machines | Se Godot ganhar |
| **Unity AI Game Creator / Unity ECS Patterns** | Plano de projeto Unity / DOTS | Se Unity entrar |
| **Blender Motion State Inspection** | Diagnóstico de rig/animação | Se houver personagens/animação em Blender |
| **Fal 3D Generation** | Geração de modelos 3D por prompt (API paga fal.ai) | Prototipagem de assets (com chave e revisão) |
| **Advanced GLSL Shader Development** | Shaders de alto desempenho | Efeitos especiais (aproveitável em várias engines) |

### ⏸️ Só se o projeto for web

Toda a família **Three.js** (design 3D, loaders, interação, animação, pós-processamento, materiais) — excelentes, mas só fazem sentido num build/protótipo web, não na engine de produção.

### ❌ Evitar

| Skill | Motivo |
|---|---|
| **Epic Games Automation** | Automação de loja/conta, não de desenvolvimento |
| **Dungeon Fighter Online Automation** | Bot de jogo alheio — risco de ToS e irrelevante pro dev |

### 🔍 Vale buscar no catálogo (long tail, não estava no topo)

Termos: `procedural generation`, `level design`, `game feel`, `vehicle physics`, `playtesting`, `game AI`, `balancing`, `pixel art`, `MetaSounds`/`Wwise`, `Unreal GAS`, `Godot vehicle`. Atenção a **duplicatas** (ex.: "Unreal Engine C++ Pro" aparece 2x, "Godot GDScript Patterns" 3x — qualidade varia; escolha a de autor com mais tração e leia o `.md` inteiro antes).

## Como incorporar (procedimento padrão)

1. Baixar a skill (repo do autor ou o link do mercado).
2. **Ler o arquivo `.md` inteiro** — procurar comandos perigosos, pedidos de credenciais, coisas contra o projeto.
3. Salvar em `skills/<nome>/` no repo, com um `skills/README.md` dizendo: origem, versão/data, quem aprovou, o que ela muda no comportamento.
4. Citar no `AGENTS.md` como "aprovada — use para X".
5. Reavaliar quando o projeto mudar de engine.

## Nota sobre este ambiente (Arena)

O que a plataforma permite nesta conversa é o que está nas *connected apps* — hoje, nada plugado (e sem conector GitHub nativo aqui). O restante do time (IA local, Colab, clientes com MCP) consome skills normalmente pelo processo acima. O **chefe** com git na sessão nova continua sendo o único a integrar no `main`.
