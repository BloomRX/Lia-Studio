# Pacote de configuração do estúdio de agents

Este pacote configura o time de IAs que desenvolve o jogo: **chefe (sessão com git) + IA local + nuvem/Colab + você**. Serve para qualquer engine e qualquer jogo — a documentação completa do projeto é quem manda nos detalhes.

## Ordem de uso

1. **`COMO_CONFIGURAR.md`** — o guia principal. Leia uma vez inteira.
2. **`templates/BOOTSTRAP_SESSAO.md`** — mensagem pronta pra abrir a primeira sessão do chefe. Copiar, preencher colchetes, enviar.
3. **`templates/AGENTS_TEMPLATE.md`** — contrato do projeto (vira o `AGENTS.md` na raiz do repositório).
4. **`templates/BRIEFING_TAREFA.md`** — formato de tarefa pros workers (IA local, Colab, nuvem).
5. **`templates/worker_colab.ipynb`** — notebook worker pronto pro Colab, com o protocolo de jobs/resultados.
6. **`skills/AVALIACAO_SKILLS.md`** — o que aproveitar dos mercados de skills (MCP Market etc.), com os riscos.

## Princípios que sustentam tudo

1. **Processo em documento, não em memória.** O que a IA precisa seguir está escrito no repo; qualquer modelo (forte ou leve) cumpre o mesmo script.
2. **Gate determinístico, não opinião.** "Pronto" só existe se o script de build/teste/validação devolver verde. Nenhuma IA declara pronto por achismo.
3. **Decisão de design é sua.** Uma pergunta por vez, com opções e recomendação.
4. **Git é o barramento.** Estado, tarefas e entregáveis trafegam por ele — workers entram e saem sem reescrever o processo.

> Referência viva: o protótipo do teste de engine ficou em `JogoProvisorio/` (raiz do workspace), com validador, `teste_unreal.bat`, ADRs e `AGENTS.md` — é um exemplo concreto do fluxo funcionando.
