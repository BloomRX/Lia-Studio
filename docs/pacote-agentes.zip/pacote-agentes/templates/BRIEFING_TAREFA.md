# Briefing de tarefa (formato obrigatório pros workers)

Uma tarefa = uma pasta em `jobs/<data>_<numero>_<slug>/`. Preencha os campos; saída fora do formato volta pra fila.

---

## Tarefa `[ID]` — [título curto]

**Para:** [IA local 14B / worker Colab / script]  
**Tentativas máximas:** 3 (depois, escalar com o log)  
**Prazo/relevância:** [ex.: bloqueia o marco 3]

### Objetivo
[Uma frase. O que precisa existir no fim.]

### Entradas
- `entrada.json` — [o que contém]
- Outros arquivos: [ ]

### Saída obrigatória (em `results/<ID>/`)
| Arquivo | Formato | Exemplo de conteúdo |
|---|---|---|
| `status.json` | `{"id": "...", "resultado": "ok\|erro", "tentativas": 1, "obs": "..."}` | |
| `saida.json` | [schema esperado, campo por campo] | |
| `log.txt` | texto livre | |

### Critérios de aceite (mensuráveis)
1. [Ex.: `saida.json` valida contra `tools/valida_dados.py`]
2. [Ex.: todos os IDs únicos; toda chave de texto tem pt-BR e en]
3. [Ex.: números dentro das faixas do briefing]

### Limites (o que a tarefa NÃO pode fazer)
- Não alterar nada fora de `results/<ID>/`.
- Não decidir design; em caso de dúvida, devolver `resultado: "erro"` com a dúvida em `obs`.
- Não usar conteúdo de outras obras (nomes, textos, arte).

### Contexto útil
[Links, trechos de doc, números de referência. Não mande o repositório inteiro nem credenciais.]
