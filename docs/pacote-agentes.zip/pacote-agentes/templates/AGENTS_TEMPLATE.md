# AGENTS.md — contrato de trabalho deste repositório

> Preencha os [colchetes]. Este arquivo manda em **qualquer IA** que trabalhe aqui — chefe, worker local ou worker de nuvem.

**Projeto:** [nome provisório] · **Engine:** [ ] · **Modo:** [solo/coop] · **Fonte de verdade:** `docs/`

## 1. Precedência

1. Decisões fechadas em `docs/[doc_de_decisoes]`.
2. Documentação principal `docs/[...]`.
3. Material de apoio.

Conflito: vale o item de cima. Registre a divergência em `docs/adr/` ou nas pendências.

## 2. Regras de ouro

- **Um marco por vez** (`docs/[marcos]`). Só avance depois do critério de aceite.
- **Pronto significa verificado:** gate verde na máquina do usuário + resumo no formato. Declarar pronto sem verificar é a pior falha.
- **Decisão de design não fechada não é da IA:** pergunte ao usuário, uma coisa por vez, com opções e recomendação. Até lá, use o padrão provisório, marcado (`PROVISORIO Px` em código, `"_provisorio"` em dados).
- **Decisão técnica é da IA:** ADR curto em `docs/adr/` (contexto, decisão, consequência) + menção no resumo.
- **Dados fora do código:** números só em `data/[balance]`; textos só em `data/[locale]`.
- **Nenhum nome de outra obra** em código, dados, textos ou documentação de produto.
- **Compilação/rodagem:** a IA provavelmente não roda a engine. A checagem real é o log do usuário. Corrija pelo log; não invente analisador próprio.

## 3. Papéis

| Papel | Faz | Não faz |
|---|---|---|
| Chefe | Orquestra, executa o difícil, integra no main, fala com o usuário | Pular gate |
| Worker (local/nuvem) | Tarefas fechadas via `jobs/` → `results/` | Decidir design, dar push no main |
| Escritão | Estado, resumos por template, fila | Julgar qualidade |
| Usuário | Design, playtest, gates na máquina | — |

## 4. Verificação

1. `tools/[validador]` — dados e regras (segundos; rode antes de tudo).
2. `tools/[gate_da_engine]` na máquina do usuário — build + testes; termina **APROVADO/REPROVADO**.
3. Checkpoints humanos: após [marcos X, Y, Z] — pare, mande o roteiro, espere.

## 5. Formato do resumo de entrega (máx. 10 linhas)

1. Situação da compilação/teste (primeira linha).
2. O que foi feito (2–3 linhas).
3. Como testar/abrir.
4. Controles (ou lista pra confirmar).
5. O que verificar em 2 minutos (5–8 itens).
6. Bugs conhecidos.
7. Decisões que precisam do usuário (opções + recomendação).

## 6. Git

- Branch por marco (`marco-N-...`); tag por entrega verificada.
- Só o chefe integra no `main`, com gate verde.
- Binários em LFS (`.gitattributes`). Ignore artefatos de build da engine.
- Nenhuma chave/token no repositório.

## 7. Registro de decisões

- **Design:** pergunta ao usuário → registre em `docs/[decisoes]`.
- **Técnica:** `docs/adr/ADR-NNN-titulo.md` + nota no resumo.
