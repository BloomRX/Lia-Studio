# COMO_CONFIGURAR — o estúdio de agents passo a passo

## 0. O mapa: quem é quem

| Quem | O que faz | O que NÃO faz |
|---|---|---|
| **Você** (direção) | Decide design, playtesta, roda os gates na sua máquina, tem a engine | Não precisa programar |
| **Chefe** (sessão Arena com git — tipo esta, mas com git ligado) | Orquestra, executa o difícil (código, debug, ADRs), escreve briefings, fala com você | Não pula gate; não decide design sozinho |
| **Squad local** (IA 8B/14B + scripts) | Workers de tarefa fechada, escrivão da fila, checagens redundantes | Não depura log estranho; não declara pronto; não dá push |
| **Nuvem/Colab** | GPU, batch grande, LLM com chave própria, paralelismo | Não substitui o chefe no julgamento |
| **Gate** (script de build/teste + validador) | A única fonte de "APROVADO/REPROVADO" | — |

Regra de bolso: **potência onde há julgamento; economia onde há volume.**

---

## 1. Configurando a sessão do chefe (a mais importante)

### 1.1 Antes de abrir a sessão

- [ ] Repositório **privado** com **Git LFS** (binários de jogo: assets, mídia).
- [ ] **Token de deploy** de escopo mínimo (só esse repositório), se o git não vier plugado na sessão. Nunca mande o token no corpo da conversa — deixe em arquivo/credencial do sistema.
- [ ] No repo, já presente: `docs/` (a documentação completa do jogo), `AGENTS.md`, `tools/` (gates), `estado/`.
- [ ] Na sua máquina: engine instalada + o script de teste do projeto (equivalente ao `teste_unreal.bat` do protótipo).

### 1.2 Bootstrap da sessão

Use `templates/BOOTSTRAP_SESSAO.md` como primeira mensagem. Ele entrega ao chefe, em ordem: papéis, documentos que são lei, como você testa, regras de ouro e o primeiro objetivo.

### 1.3 O que manter durante o trabalho

- **`estado/marco_atual.md`** — em que marco estamos, o que falta, o que travou. Atualizado a cada entrega. É o que permite retomar a sessão sem amnésia.
- **Uma decisão de cada vez** — o chefe te pergunta, você responde, ele registra (doc de decisões + ADR se for técnico).
- **Resumo padronizado** a cada entrega (recomendo o formato do protótipo: 1ª linha = situação da compilação; o que fez; como testar; o que verificar em 2 min; bugs conhecidos; decisões pendentes).

### 1.4 Higiene de sessão (importante)

- Sessão longa acumula ruído. Prefira **uma sessão por marco grande** ou por fase, e ao encerrar deixe o `estado/marco_atual.md` + um resumo de 10 linhas no repo.
- Retomada = mandar o bootstrap de novo (versão curta) + o estado atual. O chefe novo continua exatamente de onde parou.
- Logs de build/teste sempre **colados ou anexados** — nunca resumidos por você ("deu erro" não é log).

---

## 2. O contrato do projeto (`AGENTS.md`)

É o cérebro externo do time. Quanto mais processo estiver nele, mais barato pode ser qualquer modelo.

Preencha `templates/AGENTS_TEMPLATE.md` com os dados do projeto e coloque **na raiz do repositório**. Seções que não podem faltar:

1. **Precedência** — o que vence quando documentos se contradizem (ex.: doc fechado > doc rascunho > conversa).
2. **Regras de ouro** — um marco por vez; pronto = verificado; uma decisão por vez; dados fora do código; nenhum nome de outra obra; etc.
3. **Papéis** — chefe, workers, escrivão, e o que cada um decide.
4. **Verificação** — quais gates existem e como rodar; quem roda o quê.
5. **Git** — branch por marco, tag por entrega, quem pode dar push.
6. **Registro de decisões** — modelo de ADR; onde mora o doc de decisões/pendências.

---

## 3. IA local 8B/14B — o squad barato

### 3.1 Como plugear

- **Ollama** ou **LM Studio** no seu PC (modelos coder de 8–14B — família Qwen-Coder, Llama, Mistral ou equivalente atual).
- Interface tipo **Open WebUI / Cline / Continue** apontando pro modelo local, se quiser conversa.
- Programaticamente: a API local (ex.: `http://localhost:11434`) por um script Python que lê `jobs/` e escreve `results/` — o mesmo protocolo do Colab.

### 3.2 Papéis que funcionam

- **Escritão da fila:** monta status, preenche templates de resumo, lista pendências, te pergunta a próxima decisão.
- **Worker de tarefa fechada:** gerar dados de conteúdo, formatar, rodar simulações simples, checar regras que já estão escritas.
- **Revisor de primeira passada:** aponta o óbvio (nomenclatura, campos faltando, TODO esquecido).

### 3.3 O que ela não decide (nunca)

"Está pronto?", "está divertido?", causa de log estranho, arquitetura, push pro main. Modelos pequenos **esquecem regra e declaram vitória cedo** — a proteção são gates que ela não pode pular.

### 3.4 Contrato de tarefa

Toda tarefa pra ela sai no formato `templates/BRIEFING_TAREFA.md`: objetivo, entradas, **formato de saída obrigatório**, critérios de aceite mensuráveis, o que ela não pode mexer. Saída que não passa no validador volta pra fila — sem discussão.

---

## 4. Nuvens e Colab — workers remotos

### 4.1 Quando vale

GPU (render, IA pesada, treino), batches enormes, chamadas a LLMs pagos com sua chave, paralelismo real. **Para um jogo comum, grande parte do trabalho não precisa disso** — não crie nuvem por esporte.

### 4.2 O protocolo jobs/resultados (funciona em qualquer um)

```
jobs/2026-10-17_001_balance_sim/
  briefing.md        (o que fazer, formato de saída)
  entrada.json       (dados de entrada)
results/2026-10-17_001_balance_sim/
  status.json        (ok | erro, tentativas, tempo)
  saida.json         (o que foi pedido)
  log.txt            (para debug)
```

O worker (notebook, script local, CI) **puxa job → executa → escreve result → commita**. O chefe valida e integra. O `templates/worker_colab.ipynb` já vem com esse ciclo pronto.

### 4.3 Colab — a realidade

- **Não existe API oficial para disparar execução no Colab.** O ciclo natural é semi-automático: o chefe prepara o job, você abre o notebook e roda (botão), o resultado volta pelo git.
- Para automação de verdade, use quem tem API: **GitHub Actions** (build/teste no push), **Modal / Replicate / Hugging Face Inference / RunPod** (GPU sob demanda), ou um Jupyter seu exposto com token.
- **Chaves de API:** nunca no chat, nunca no git. Use *secrets* do Colab / variáveis de ambiente. Token de git também (Colab secrets).

### 4.4 O que não fazer no worker remoto

Trabalho que precisa de julgamento de design, decisão de arquitetura, ou "fechar marco". Lá é fábrica, não diretoria.

---

## 5. O barramento: git como fila de trabalho

Estrutura recomendada no repositório:

```
docs/            documentação completa (é a lei)
docs/adr/        decisões técnicas (contexto, decisão, consequência)
estado/          marco_atual.md, resumo_ultimo.md
jobs/            tarefas abertas (uma pasta por tarefa)
results/         entregáveis dos workers
data/            fonte única de dados do jogo (números, textos, conteúdo)
tools/           validadores e gates (rodáveis no seu PC e nos workers)
skills/          skills de terceiro revisadas (opcional, ver seção 7)
```

Convenções:

- **Branch por marco** (`marco-1-...`), **tag por entrega verificada** (`entrega-m3`).
- Só o chefe integra no `main`, e só com gate verde.
- Workers escrevem em `jobs/`+`results/` ou em branches próprias — nunca no `main`.

---

## 6. Gates e escalação

### Gates por engine (escolha os do seu projeto)

| Engine | Gate de build + teste na sua máquina |
|---|---|
| Unreal | `teste_unreal.bat` → Build.bat + Automation Tests (`-NullRHI`) |
| Godot | `godot --headless` + GUT/GdUnit em modo CI |
| Unity | `Unity -batchmode -runTests` (Test Runner) |

Some a isso o **validador de dados** (equivalente ao `tools/valida_dados.py` do protótipo) — roda em segundos, antes de qualquer build.

### Cadeia de escalação

```
worker local → trava 3x / log estranho / ambiguidade
   → ESCALA pro chefe (com o log completo)
chefe → decisão de design / dinheiro / risco / gosto seu
   → ESCALA pra você (uma pergunta, opções, recomendação)
```

Ninguém pula o gate. Nem o chefe. Nem você (desculpa 😄 — playtest é gate humano).

---

## 7. Skills e ferramentas de terceiro

Skills são **instruções em arquivo `.md`** que um agent executa. Úteis (boas skills são bons manuais embutidos), mas: **skill de terceiro é código que roda na cabeça da IA** — revise antes de usar, guarde em `skills/` e cite no `AGENTS.md` o que está aprovado.

A avaliação do que existe hoje está em `skills/AVALIACAO_SKILLS.md` (MCP Market).

---

## 8. Segurança (resumo)

- Repositório privado; token de escopo mínimo; **nenhuma chave em arquivo versionado**.
- O chefe é o único com poder de escrita no `main`.
- Workers recebem apenas os dados do job — não o repositório inteiro com credenciais.
- Skills/scripts de terceiro passam por revisão antes de entrar em `skills/`.

---

## 9. O que o teste de engine já provou (aproveite)

1. **Docs + processo escrito funcionam:** o agente cumpriu marcos, ADRs e formato de resumo porque estava escrito.
2. **Validação em duas pernas** (worker rápido local + gate na máquina) pega erro antes do playtest humano.
3. **Primeiro ciclo sem binários** acelera tudo: tela/cena gerada por código antes de existir asset. Vale em qualquer engine.
4. **Research antes de arquitetar** (checar versão da engine, o que ela oferece) evita construir sobre suposição.
